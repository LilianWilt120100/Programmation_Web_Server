<?php
    // Ce tableau associe un nom d'utilisateur à un mot de passe :
    //    user => password
    $users = [
        'adrien' => 'adrien',
        'gabriel' => 'gabriel',
		'gil' => 'gross',
    ];
